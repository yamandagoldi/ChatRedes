users = document.getElementsByClassName("user")

for( i = 0; i < users.length; i++){
    users[i].addEventListener("click", function(){ window.location.href ="chat.html"})
}
