me = "Amanda";
btnSend = document.getElementById('am');
btnSend.addEventListener("click", function(e){
inputMessage = document.getElementById('at');  
sendMessage( inputMessage.value  );
});

function sendMessage(message){
    arr = {user: me, msg: message}
    ws.send( JSON.stringify(arr) ); 
    }

    
function displayMessage(temp){
    chat = document.getElementById("diva");
    className = "mymsg";
    
    if (temp.user == you){
        className = "yourmsg";
    }
    chat.InnerHTML = chat.InnerHTML + "<div class='"+className+"'>" + temp.msg + "</div>"
}
